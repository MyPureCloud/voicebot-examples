'use strict';

const NO_INPUT_COUNT = 'Genesys-No-Input-Count';
const NO_INPUT_LIMIT = 'Genesys-No-Input-Limit';

module.exports = {
    NO_INPUT_COUNT,
    NO_INPUT_LIMIT
};